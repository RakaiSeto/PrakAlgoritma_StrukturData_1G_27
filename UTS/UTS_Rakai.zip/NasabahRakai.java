package UTS;

public class NasabahRakai {
    String norek, nama, nik;
    int umur;
    double saldo;

    public NasabahRakai(String norek, String nama, String nik, int umur, double saldo) {
        this.norek = norek;
        this.nama = nama;
        this.nik = nik;
        this.umur = umur;
        this.saldo = saldo;
    }
}
