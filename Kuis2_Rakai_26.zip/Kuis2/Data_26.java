package Kuis2;

public class Data_26 {
    int urutan;
    Pembeli_26 pembeli;
    Pesanan_26 pesanan;

    public Data_26(int urutan, Pembeli_26 pembeli, Pesanan_26 pesanan) {
        this.urutan = urutan;
        this.pembeli = pembeli;
        this.pesanan = pesanan;
    }
}
