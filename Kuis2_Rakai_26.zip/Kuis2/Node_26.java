package Kuis2;

//import P9.Node;

public class Node_26 {
    Data_26 data_26;
    Node_26 prev_26;
    Node_26 next_26;

    public Node_26(Data_26 d, Node_26 p, Node_26 n) {
        data_26 = d;
        prev_26 = p;
        next_26 = n;
    }
}
