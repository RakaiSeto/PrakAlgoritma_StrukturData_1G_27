package Kuis2;

public class Pembeli_26 {
    String NamaPembeli_26, NoHp_26;

    public Pembeli_26(String np, String hp){
        this.NamaPembeli_26 = np;
        this.NoHp_26 = hp;
    }
}
