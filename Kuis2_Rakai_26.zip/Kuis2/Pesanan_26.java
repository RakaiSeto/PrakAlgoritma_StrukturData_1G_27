package Kuis2;

public class Pesanan_26 {
    int KodePesanan_26, Harga_26;
    String NamaPesanan_26;

    public Pesanan_26(int kp, String np, int h){
        KodePesanan_26 = kp;
        NamaPesanan_26 = np;
        Harga_26 = h;
    }
}
